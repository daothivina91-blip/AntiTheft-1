package com.example.antitheft

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class AlarmActivity : Activity() {

    // Mật khẩu siêu bảo mật đã được cập nhật
    private val correctPassword = "7\$vQ#9zX!m"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Giao diện thuần nhẹ nhẹ, biên dịch nhanh và không lỗi SDK
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(50, 50, 50, 50)
        }

        val titleText = TextView(this).apply {
            text = "⚠️ CẢNH BÁO BÁO ĐỘNG ⚠️"
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 40)
        }

        val passwordInput = EditText(this).apply {
            hint = "Nhập mật khẩu để tắt"
            // Cho phép nhập chữ, số và ký tự đặc biệt
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            gravity = Gravity.CENTER
        }

        val stopButton = Button(this).apply {
            text = "TẮT BÁO ĐỘNG"
            setOnClickListener {
                val input = passwordInput.text.toString()
                if (input == correctPassword) {
                    Toast.makeText(this@AlarmActivity, "Tắt báo động thành công!", Toast.LENGTH_SHORT).show()
                    finish() // Đúng mật khẩu mới cho phép tắt app
                } else {
                    Toast.makeText(this@AlarmActivity, "Sai mật khẩu! Không thể tắt!", Toast.LENGTH_SHORT).show()
                    passwordInput.setText("")
                }
            }
        }

        layout.addView(titleText)
        layout.addView(passwordInput)
        layout.addView(stopButton)

        setContentView(layout)
    }

    // Chặn hoàn toàn nút Back (Trở về)
    override fun onBackPressed() {
        Toast.makeText(this, "Yêu cầu nhập mật khẩu để thoát!", Toast.LENGTH_SHORT).show()
    }

    // Tự động nhảy lại màn hình nếu trộm cố vuốt ẩn app/về màn hình chính
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val intent = Intent(this, AlarmActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        }
        startActivity(intent)
    }
}