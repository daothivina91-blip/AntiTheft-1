package com.example.antitheft

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            
            // 1. Tự động bật Wi-Fi để tự dò kết nối mạng gần nhất
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (!wifiManager.isWifiEnabled) {
                @Suppress("DEPRECATION")
                wifiManager.isWifiEnabled = true
            }

            // 2. Tự động bật lại báo động nếu máy vừa được bật nguồn lên
            val prefs = context.getSharedPreferences("AntiTheftPrefs", Context.MODE_PRIVATE)
            val isAlarmActive = prefs.getBoolean("is_alarm_active", false)

            if (isAlarmActive) {
                val alarmIntent = Intent(context, AlarmActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(alarmIntent)
            }
        }
    }
}